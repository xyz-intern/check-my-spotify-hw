/*
 * tm1637_config.h
 *
 *  Created on: Oct 31, 2023
 *      Author: sion
 */

#ifndef INC_TM1637_CONFIG_H_
#define INC_TM1637_CONFIG_H_

#define _TM1637_FREERTOS            0
#define _TM1637_BIT_DELAY           20

#endif /* INC_TM1637_CONFIG_H_ */
